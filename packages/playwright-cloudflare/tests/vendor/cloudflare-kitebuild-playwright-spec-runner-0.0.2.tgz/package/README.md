# @cloudflare/kitebuild-playwright-spec-runner

Runs upstream Playwright Test's worker processes in Worker Loader isolates,
one isolate each, with IPC, stdio and project files carried between them and
the runner (CLI, config, collection, scheduling, retries, reporters). The
runner runs either in an isolate too, or as upstream's own CLI in Node.

The package contains no Playwright code. Playwright comes from the consumer's
own install.

## Building the payloads (Node)

```js
import { buildRunnerPayload, buildWorkerPayload } from "@cloudflare/kitebuild-playwright-spec-runner/build";

const runner = await buildRunnerPayload({ playwright: "/path/to/node_modules/playwright" });
const worker = await buildWorkerPayload({
  playwright: "/path/to/node_modules/playwright",
  cloudflarePlaywright: "/path/to/node_modules/@cloudflare/playwright",
});
```

Both come from the installed `playwright`, which must be exactly the version
`@cloudflare/playwright` was built from (checked). The worker takes only the
browser client from `@cloudflare/playwright`, through its public entry;
`chromium.launch` acquires a browser through the worker isolate's `BROWSER`
binding and passes Browser Run options (`keep_alive`, `recording`, `lab`,
`guardrails`, `outboundByHost`) through.

No upstream source text is edited. Node APIs Playwright relies on are
substituted as whole modules (`child_process`, `crypto`, `module`, `fs`) and
the bundle gets its own `require`; see the table in `src/build/index.mjs`.
Private files of `playwright` are imported by path: up to 1.61
`lib/common/process.js`, `lib/worker/workerMain.js` and
`lib/transform/compilationCache.js`; from 1.62, whose `lib/` is bundled,
`lib/worker/workerProcessEntry.js` and `lib/common/index.js`. When bumping
`playwright`, recheck those and the call sites in that table.

Projects must not be ES modules for upstream's loader: no `"type": "module"`
and no `.mjs`/`.mts` files, or upstream reaches `eval(import())`.

A project bundle should leave `@cloudflare/playwright` external. Worker
isolates resolve it to the worker payload's own client, which its header lists
the names of, so the specs drive the same client Playwright Test does and no
isolate holds a second copy and its source maps. Runner isolates, which only
collect tests, get a stand-in that fails when called.

## Running (Worker)

`runPlaywrightPhase(options)` runs one pass. Payloads built above support
`phase: "run"` with prebundled project modules. Kitebuild's own text-edited
payloads (no header) also support `phase: "collect"`, which stops once the
config and CLI filters are applied and returns the files the run needs. A
runner and worker from different builds or `playwright` versions are refused.

Worker isolates read project files from the tree given to the phase:
contents the tree carries (`text`) are read synchronously, others are fetched
from the host asynchronously; writes go to the host.

Binary files go in `bundle.files`, which every isolate (runner and workers)
receives as data modules that its own `node:fs` reads at `/bundle/<key>`,
so specs and the browser client can read them by that path. A tree file whose
`module` names one of those keys has its bytes as contents, which upstream
can read synchronously (snapshots); only built payloads and the runner of
Kitebuild's text-edited payloads read `module`. Each isolate gets every file,
so send only what the run reads.

### Memory

A worker isolate has about 262 MiB in all; an idle worker process (the
payload evaluated) leaves about 196 MiB for tests, measured with
`probes/playwright-isolate-memory` against browser-run's pilot. A worker
process runs many tests in one isolate, so two things build up:

- Files under `/tmp` are charged to the isolate until removed. Attachments
  reach the runner with their bytes, so nothing else reads a test's output
  there: set `preserveOutput: "never"` in the config, and upstream removes
  each test's output directory after the test ends. Upstream's default,
  `"always"`, keeps every test's output for the life of the isolate. Set
  `KITEBUILD_PLAYWRIGHT_TMP_REPORT` in a worker's environment to have it
  report what its `/tmp` holds as each test begins.
- A full-page screenshot comparison can leave more than 100 MiB charged
  until the isolate collects it, and a long-lived isolate need not collect
  before the next test needs the memory. Give each test an isolate of its
  own: `fullyParallel: true` in the config makes each independent test a
  group, and `groupsPerIsolate: 1` starts every group in a fresh isolate.
  Serial groups stay whole. Neither setting alone is enough, and no setting
  helps a single test that needs more than the isolate has.

A fresh isolate per test should not mean a fresh browser per test. Acquire one
Browser Run session per worker slot in Node, hand the IDs to the isolates, and
let each worker process connect and disconnect:

```js
// Node: one session per worker slot, closed when Playwright is done.
// runPlaywright exits the process when Playwright reports, so run it in a child
// process and close the sessions in the parent.
await runPlaywright({
  workerUrl, projectRoot, buildIdFile, headers, args,
  groupsPerIsolate: 1,
  forwardEnv: ["BROWSER_SESSION_IDS"], // "id0,id1,...", one per --workers
});
```

```ts
// Worker fixture: connect to the slot's session; close() only disconnects.
browser: [async ({ binding }, run, workerInfo) => {
  const sessionId = process.env.BROWSER_SESSION_IDS!.split(",")[workerInfo.parallelIndex];
  const browser = await connect(binding, sessionId);
  await run(browser);
  await browser.close();
}, { scope: "worker" }],
```

browser-run's pilot (`packages/playwright-cloudflare/tests/runner/run.mjs`)
does this, including acquiring and closing the sessions. Startup per test makes
runs slower; size suite timeouts for it.

The worker payload's client shares upstream's `utilsBundle` (pngjs, jpeg-js,
ws, the MCP SDK and the rest) instead of carrying its own copy. That makes the
payload about 2 MB smaller; an idle isolate's headroom did not measurably
change.

Worker entries stop source-map-support from reading files. Upstream supplies
the maps it has; without one, the library would read the whole payload looking
for an inline map and keep the text, about 22 MB for the core module. Rebuild a
worker payload to get this.

`collectProjectFiles` (from `/build`) reads both kinds from disk. Given the
config's `snapshotPathTemplate` and the bundled test files, it finds the
snapshots Playwright will look for, expanding the template as upstream does
with `{arg}`, `{testName}` and `{ext}` as wildcards, and returns them with their
tree nodes. Files specs open by path are chosen by globs:

```js
const { files, nodes } = collectProjectFiles({
  snapshots: {
    snapshotPathTemplate: "{testDir}/{testFileDir}/{testFileName}-snapshots/{arg}-chromium{ext}",
    testDir: "/project/tests",
    testFiles: ["/project/tests/page/page-basic.spec.ts"],
    resolve: (dir) => onDisk(dir), // virtual directory -> directory on disk
  },
  assets: [{ dir: "/path/to/tests", include: ["assets/**/*.pem"] }], // /bundle/assets/...
});
```

## Running the runner in Node

Where Node is at hand, as in CI, upstream's runner can run there unchanged and
send only its worker processes to isolates: no isolate holds the whole run, and
reporters write to local disk as usual. The Worker serves one worker process
per WebSocket and needs only the worker payload:

```ts
import { servePlaywrightWorker } from "@cloudflare/kitebuild-playwright-spec-runner";

// After authorizing the request:
return servePlaywrightWorker(request, ctx, {
  build: BUILD_ID, // of the payload, tree and bundle below
  loader: env.LOADER,
  compatibilityDate,
  payload: WORKER_PAYLOAD,
  tree,
  bundle,
  files,
  env: { CI: "1" },
  workerBindings: (processEnv) => ({ BROWSER: env.BROWSER }),
});
```

Node lists the tests from its own copy of the project, laid out like the
isolates' root (the tree's first root), and runs them with
`kitebuild-playwright`, which takes `playwright test`'s arguments:

```sh
kitebuild-playwright test --worker-url https://tests.example/worker --project-root dist/node/project \
  --build-id-file dist/build-id --header "Authorization: Bearer $TOKEN" --forward-env BROWSER_BINDING --shard=1/4
```

It refuses a Worker deployed from another build, or built from another
`playwright`, before starting: their test IDs need not match. Upstream's
`lib/runner/processHost.js` alone gets a `child_process` whose `fork` opens the
WebSocket; paths in messages are rewritten between the two roots, and each
worker process receives only the environment the runner set for it plus the
`--forward-env` variables.

Where the copy Node lists from is bundled, its source maps give test locations
in the original sources. The isolates report errors and steps by their own
paths; `--sources-file` (`sources` for `runPlaywright`) names, as JSON from
isolate path to local path relative to the file, the source each such file
reports for, so locations and code frames read the original too.

An isolate has far less memory than a Node process, and a worker process
accumulates state across the files it runs. `--groups-per-isolate N` moves each
worker process to a fresh isolate before its N+1th test group: the old isolate
is stopped as upstream stops a worker, its teardown still reported, and the new
one set up as the first was. The runner sees one process throughout.

The copy Node lists from may differ from the isolates' modules, for example
where it stubs what exists only in a Worker. `kitebuild-playwright check-tests
--list-url <url> --project-root <dir>` lists the tests on both sides and names
every test whose ID or expected status differs; the route answers a POST of
`{ args }` with `listPlaywrightTests(options, args)`, which needs the runner
payload and may run locally (`wrangler dev`).

## Consumers

Kitebuild's `playwright` applet (`packages/toolchain/src/playwright`, see
`docs/playwright-test.md`), with text-edited payloads and a two-phase run.
`probes/playwright-runner-substitutions` runs built payloads in a deployed
Worker. browser-run's `@cloudflare/playwright` test suite runs its runner in
Node.
