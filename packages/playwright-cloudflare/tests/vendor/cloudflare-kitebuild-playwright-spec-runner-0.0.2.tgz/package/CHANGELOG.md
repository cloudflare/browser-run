# @cloudflare/kitebuild-playwright-spec-runner

## 0.0.2

### Patch Changes

- b99a517: Licensed under Apache-2.0, with the licence text in each package.

## 0.0.1

First release, to Cloudflare's internal npm registry. Runs upstream Playwright Test in Worker Loader isolates.
