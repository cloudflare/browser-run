# @cloudflare/kitebuild-playwright-spec-runner

## 0.0.1

First release, to Cloudflare's internal npm registry. Runs upstream Playwright Test in Worker Loader isolates.
