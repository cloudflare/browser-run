# @cloudflare/kitebuild-playwright-spec-runner

Runs upstream Playwright Test in Worker Loader isolates: the runner (CLI,
config, collection, scheduling, retries, reporters) in one isolate, and each
worker process it forks in an isolate of its own, with IPC, stdio and project
files carried between them by the host.

The package contains no Playwright code. Playwright comes from the consumer's
own install.

## Building the payloads (Node)

```js
import { buildRunnerPayload, buildWorkerPayload } from "@cloudflare/kitebuild-playwright-spec-runner/build";

const runner = await buildRunnerPayload({ playwright: "/path/to/node_modules/playwright" });
const worker = await buildWorkerPayload({
  playwright: "/path/to/node_modules/playwright",
  cloudflarePlaywright: "/path/to/node_modules/@cloudflare/playwright",
});
```

Both come from the installed `playwright`, which must be exactly the version
`@cloudflare/playwright` was built from (checked). The worker takes only the
browser client from `@cloudflare/playwright`, through its public entry;
`chromium.launch` acquires a browser through the worker isolate's `BROWSER`
binding and passes Browser Run options (`keep_alive`, `recording`, `lab`,
`guardrails`, `outboundByHost`) through.

No upstream source text is edited. Node APIs Playwright relies on are
substituted as whole modules (`child_process`, `crypto`, `module`, `fs`) and
the bundle gets its own `require`; see the table in `src/build/index.mjs`.
Two private files of `playwright` are imported by path
(`lib/common/process.js`, `lib/worker/workerMain.js`). When bumping
`playwright`, recheck those and the call sites in that table.

Projects must not be ES modules for upstream's loader: no `"type": "module"`
and no `.mjs`/`.mts` files, or upstream reaches `eval(import())`.

## Running (Worker)

`runPlaywrightPhase(options)` runs one pass. Payloads built above support
`phase: "run"` with prebundled project modules. Kitebuild's own text-edited
payloads (no header) also support `phase: "collect"`, which stops once the
config and CLI filters are applied and returns the files the run needs. A
runner and worker from different builds or `playwright` versions are refused.

Worker isolates read project files from the tree given to the phase:
contents the tree carries (`text`) are read synchronously, others are fetched
from the host asynchronously; writes go to the host.

Binary files go in `bundle.files`, which every isolate (runner and workers)
receives as data modules that its own `node:fs` reads at `/bundle/<key>`,
so specs and the browser client can read them by that path. A tree file whose
`module` names one of those keys has its bytes as contents, which upstream
can read synchronously (snapshots); only built payloads and the runner of
Kitebuild's text-edited payloads read `module`. Each isolate gets every file,
so send only what the run reads.

## Consumers

Kitebuild's `playwright` applet (`packages/toolchain/src/playwright`, see
`docs/playwright-test.md`), with text-edited payloads and a two-phase run.
`probes/playwright-runner-substitutions` runs built payloads in a deployed
Worker.
